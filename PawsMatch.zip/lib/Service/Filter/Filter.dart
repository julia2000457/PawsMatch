import 'package:flutter/material.dart';

class Animals {
  Animals({required this.Category, required this.ID});

  Animals.fromJson(Map<String, Object?> json)
      : this(
          Category: json['Category']! as String,
          ID: json['ID']! as String,
        );

  final String Category;
  final String ID;

  Map<String, Object?> toJson() {
    return {
      'Category': Category,
      'ID': ID,
    };
  }

  final animalsRef =
      FirebaseFirestore.instance.collection('animals').withConverter<Animals>(
            fromFirestore: (snapshot, _) => Animals.fromJson(snapshot.data()!),
            toFirestore: (animal, _) => animal.toJson(),
          );
  Future<void> main() async {
    // Obtain Cats from category
    List<QueryDocumentSnapshot<Animals>> animals = await animalsRef
        .where('Category', isEqualTo: 'Cats')
        .get()
        .then((snapshot) => snapshot.docs);
  }
}
